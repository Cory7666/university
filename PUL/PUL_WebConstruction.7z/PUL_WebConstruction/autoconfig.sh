#!/bin/bash

sudo apt install apache2 pdo-mysql