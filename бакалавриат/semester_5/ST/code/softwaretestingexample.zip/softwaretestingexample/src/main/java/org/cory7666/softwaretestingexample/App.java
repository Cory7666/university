package org.cory7666.softwaretestingexample;

import java.io.File;

import org.cory7666.softwaretestingexample.task1.FileWithMatrix;
import org.cory7666.softwaretestingexample.task1.Matrix;

public class App
{
	public static void main (String[] args) throws Exception
	{
		if (args.length != 2)
		{
			System.err.println("Usage: program [file-with-matrix] [single or multi]");
			System.exit(1);
		}
		else
		{
			final File file = new File(args[0]);
			System.out.printf("Получен файл \"%s\".%n", file.toPath());
			final Matrix matrix = new FileWithMatrix(file).parse();
			System.out.println("Данные из файла считаны.");

			int result;
			switch (args[1])
			{
			case "single":
				System.out.println("Использование одного потока.");
				result = matrix.columnPositionWithLongestSeries();
				break;
			case "multi":
				System.out.println("Использование всех потоков.");
				result = matrix.columnPositionWithLongestSeriesParallel();
				break;
			default:
				throw new Exception();
			}
			System.out.printf("Ответ: %d.%n", result);

			System.out.println("Выполнения програмы завершено.");
			System.exit(0);
		}
	}
}
