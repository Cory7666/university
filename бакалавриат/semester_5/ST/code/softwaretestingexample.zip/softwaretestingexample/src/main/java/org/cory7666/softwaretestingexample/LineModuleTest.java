package org.cory7666.softwaretestingexample;

import java.io.PrintStream;
import java.util.Collection;

import org.cory7666.softwaretestingexample.task3.MyLine;

public class LineModuleTest implements AutoCloseable
{
	private int testNumCounter;
	private final Collection<PrintStream> outputStreams;

	public LineModuleTest (Collection<PrintStream> outputStreams)
	{
		this.testNumCounter = 0;
		this.outputStreams = outputStreams;
	}

	public LineModuleTest test (String testCase, boolean expected)
	{
		++testNumCounter;
		boolean result = new MyLine(testCase).containsThreeDigitNumber();

		outputStreams.forEach(writer -> {
			try
			{
				writer.println(String.format("-===        Тест %2d        ===-", testNumCounter));
				writer
					.println(
						String
							.format(
								"Строка: \"%s\". Ожидаемый результат: %b. Получено: %b.",
								testCase,
								expected,
								result));
				writer.println(String.format("-=== Завершение теста %2d ===-\n", testNumCounter));
			}
			catch (Exception ex)
			{}
		});

		return this;
	}

	@Override
	public void close () throws Exception
	{
		for (var stream : outputStreams)
		{
			try
			{
				stream.close();
			}
			catch (Exception ex)
			{}
		}
	}
}
