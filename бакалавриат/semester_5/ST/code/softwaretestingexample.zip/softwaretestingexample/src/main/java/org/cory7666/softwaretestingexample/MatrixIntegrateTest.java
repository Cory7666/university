package org.cory7666.softwaretestingexample;

import java.io.PrintStream;
import java.util.List;

import org.cory7666.softwaretestingexample.task1.Matrix;

public class MatrixIntegrateTest implements AutoCloseable
{
	private final List<PrintStream> streams;
	private final Matrix input;

	public MatrixIntegrateTest (Matrix input, List<PrintStream> streams)
	{
		this.streams = streams;
		this.input = input;
	}

	public MatrixIntegrateTest test (int column, int[] newData, Class<? extends Exception> expectedException)
	{
		writeString("-=== Начало теста. ===-");
		writeString("До изменения:");
		dump();
		writeString(String.format("Замена данных в позиции %d.", column));
		try
		{
			input.replaceColumnWith(column, newData);
			
		}
		catch (Exception ex)
		{
			writeString("!!! Поймано исключение !!!");
			writeString(
				String.format("* Тип: %s. Текст: %s.", ex.getClass().getName(), ex.getMessage()));
			if (ex.getClass().equals(expectedException))
			{
				writeString("* Исключение было ожидаемым.");
			}
			else
			{
				writeString("* Исключение неожидано или имеет неверный тип.");
			}
		}
		writeString("После изменения:");
		dump();
		
		writeString("-=== Конец теста. ===-\n");

		return this;
	}

	private void dump ()
	{
		var matrixString = input.toString();
		writeString(matrixString);
	}

	private void writeString (String x)
	{
		streams.forEach(stream -> stream.println(x));
	}

	@Override
	public void close () throws Exception
	{
		streams.forEach(x -> x.close());
	}
}
