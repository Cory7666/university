package org.cory7666.softwaretestingexample;

import com.opencsv.bean.CsvBindByName;

public class ModuleTestCase
{
	@CsvBindByName (column = "line") public String line;
	@CsvBindByName (column = "expected") public String expected;
}
