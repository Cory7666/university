package org.cory7666.softwaretestingexample.task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

public class FileWithMatrix
{
	private final File file;

	public FileWithMatrix (File file)
	{
		this.file = file;
	}

	public Matrix parse () throws IOException
	{
		try (var reader = Files.newBufferedReader(file.toPath()))
		{
			List<Integer> matrixSize = Arrays.stream(reader.readLine().split("\\s")).map(Integer::parseInt).toList();
			List<Integer> integers = Arrays.stream(reader.readLine().split("\\s")).map(Integer::parseInt).toList();
			int integerPointer = 0;

			int[][] matrixAsArrays = new int[matrixSize.get(0)][matrixSize.get(1)];

			for (var column : matrixAsArrays)
			{
				for (int i = 0; i < column.length; ++i)
				{
					column[i] = integers.get(integerPointer++);
				}
			}

			return new Matrix(matrixAsArrays);
		}
	}
}
