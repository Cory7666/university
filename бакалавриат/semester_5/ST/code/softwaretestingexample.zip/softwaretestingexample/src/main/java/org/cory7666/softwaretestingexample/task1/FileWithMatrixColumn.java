package org.cory7666.softwaretestingexample.task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;

public class FileWithMatrixColumn
{
	private final File file;
	
	public FileWithMatrixColumn (File file)
	{
		this.file = file;
	}
	
	public int[] parse() throws IOException
	{
		try (var reader = Files.newBufferedReader(file.toPath()))
		{
			return Arrays.stream(reader.readLine().split("\\s")).mapToInt(Integer::parseInt).toArray();
		}
	}
}
