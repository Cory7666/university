package org.cory7666.softwaretestingexample.task1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class Matrix implements Iterable<MatrixColumn>, Cloneable
{
	private final List<MatrixColumn> matrix;
	public final int rows, cols;

	public Matrix (int[][] data)
	{
		try
		{
			this.cols = data.length;
			this.rows = data[0].length;

			this.matrix = new ArrayList<>(this.cols);
			for (int i = 0; i < data.length; ++i)
			{
				this.matrix.add(new MatrixColumn(i, data[i]));
			}
		}
		catch (NullPointerException e)
		{
			throw new IllegalArgumentException("Argument data cann't be null.");
		}
	}

	public int columnPositionWithLongestSeries ()
	{
		Series answer = new Series(-1, -1);
		for (var column : matrix)
		{
			var maxFromColumn = Collections.max(column.getAllPosibleSeries());
			if (maxFromColumn.counter() >= answer.counter())
			{
				try
				{
					Thread.sleep(100);
				}
				catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				answer = maxFromColumn;
			}
		}
		return answer.col;
	}

	public int columnPositionWithLongestSeriesParallel ()
	{
		Series answer = new Series(-1, -1);
		final List<CompletableFuture<Series>> futures = matrix
			.parallelStream()
			.map(x -> CompletableFuture.supplyAsync( () -> {
				return Collections.max(x.getAllPosibleSeries());
			}))
			.toList();

		for (var future : futures)
		{
			final Series result = future.join();
			if (result.counter() >= answer.counter())
			{
				answer = result;
			}
		}

		return answer.col;
	}

	public void replaceColumnWith (int columnIndex, int[] newData)
	{
		try
		{
			matrix.get(columnIndex).replaceWith(newData);
		}
		catch (Exception ex)
		{
			throw new IllegalArgumentException("Wrong column index.");
		}
	}

	public MatrixColumn getColumn (int col)
	{
		return matrix.get(col);
	}

	@Override
	public Iterator<MatrixColumn> iterator ()
	{
		return matrix.iterator();
	}

	@Override
	public String toString ()
	{
		var ret = new StringBuilder();

		for (int i = 0; i < rows; ++i)
		{
			for (var col : matrix)
			{
				ret.append(col.get(i) + "\t");
			}

			if (i + 1 != rows)
				ret.append('\n');
		}

		return ret.toString();
	}
}
