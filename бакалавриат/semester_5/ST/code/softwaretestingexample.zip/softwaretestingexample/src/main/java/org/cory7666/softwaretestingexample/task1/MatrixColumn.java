package org.cory7666.softwaretestingexample.task1;

import java.util.HashSet;
import java.util.Set;

public class MatrixColumn
{
	public final int colIndex;
	private int[] data;

	public MatrixColumn (int colIndex, int[] data)
	{
		this.data = data;
		this.colIndex = colIndex;
	}

	public Set<Series> getAllPosibleSeries ()
	{
		Set<Series> ret = new HashSet<>();
		var currentSeries = new Series(colIndex, data[0]);

		for (int i = 1; i < data.length; ++i)
		{
			if (data[i] == currentSeries.value)
			{
				currentSeries.increase();
			}
			else
			{
				ret.add(currentSeries);
				currentSeries = new Series(colIndex, data[i]);
			}
		}

		ret.add(currentSeries);
		try
		{
			Thread.sleep(1);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	public int get (int i)
	{
		return data[i];
	}

	public void replaceWith (int[] newData)
	{
		if (newData.length != data.length)
			return;
		for (int i = 0; i < data.length; ++i)
		{
			data[i] = newData[i];
		}
	}
}
