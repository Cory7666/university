package org.cory7666.softwaretestingexample.task1;

public class Series implements Comparable<Series>
{
	public final int col, value;
	private int counter;

	public Series (int col, int value)
	{
		this.col = col;
		this.value = value;
		this.counter = 1;
	}

	public int counter ()
	{
		return counter;
	}

	public void increase ()
	{
		++counter;
	}

	@Override
	public int compareTo (Series o)
	{
		return this.counter() - o.counter();
	}
}
