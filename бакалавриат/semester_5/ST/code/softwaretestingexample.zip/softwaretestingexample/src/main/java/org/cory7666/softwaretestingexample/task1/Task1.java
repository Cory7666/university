package org.cory7666.softwaretestingexample.task1;

import java.util.Collections;

public class Task1
{
	public Task1 ()
	{
		System.out.println("=== Тесты для Задания 1 ===");
	}

	public void execute ()
	{
		this
			.test(new Matrix(new int[][] { { 1 } }), 0)
			.test(new Matrix(new int[][] { { 1, 1, 2, 1 }, { 2, 4, 78, 100 }, { 3, 5, 11, 5 } }), 0)
			.test(
				new Matrix(new int[][] { { 1, -1, 10, 20 }, { 1, 2, 2, 20 }, { 1, -1, 10, 20 }, { 1, -1, 10, 20 } }),
				1)
			.test(
				new Matrix(
					new int[][] { { 1, 2, 2, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 10, 10, 10 } }),
				4);
	}

	private Task1 test (Matrix matrix, int expect)
	{
		System.out
			.printf(
				"Матрица: {\n%s\n}. Ожидается: <%d>. Получено: <%d>.\n",
				matrix,
				expect,
				matrix.columnPositionWithLongestSeries());
		return this;
	}
}
