package org.cory7666.softwaretestingexample.task2;

public class MyString
{
	private final String string;

	public MyString (String string)
	{
		if (string == null)
			throw new IllegalArgumentException("Passed string is null.");
		this.string = string;
	}

	public String replaceCharacters ()
	{
		return string.replaceAll("!", "?");
	}
}
