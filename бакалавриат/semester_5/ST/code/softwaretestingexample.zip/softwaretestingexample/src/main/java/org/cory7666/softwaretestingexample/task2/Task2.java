package org.cory7666.softwaretestingexample.task2;

public class Task2
{
	public Task2 ()
	{
		System.out.println("=== Тесты для Задания 2 ===");
	}

	public void execute ()
	{
		this
			.test("", "")
			.test("simple string", "simple string")
			.test("!!!cómo estás", "???cómo estás")
			.test("How're you! I'm fine!", "How're you? I'm fine?");
	}

	private Task2 test (String toTest, String expect)
	{
		var result = new MyString(toTest).replaceCharacters();
		System.out
			.printf(
				"Тест для: <%s>. Ожидается: <%s>. Получено: <%s>. Итог: %b.\n",
				toTest,
				expect,
				result,
				result.equals(expect));
		return this;
	}
}
