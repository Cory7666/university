package org.cory7666.softwaretestingexample.task3;

public class MyLine
{
	public final String line;

	public MyLine (String line)
	{
		this.line = line;
	}

	public boolean containsThreeDigitNumber ()
	{
		int digitCounter = 0;
		for (int i = 0; i < line.length(); ++i)
		{
			if ('0' <= line.charAt(i) && line.charAt(i) <= '9')
			{
				if (('1' <= line.charAt(i) && line.charAt(i) <= '9') || (line.charAt(i) == '0' && digitCounter != 0))
				{
					++digitCounter;
				}
			}
			else
			{
				digitCounter = 0;
			}

			if (digitCounter == 3 && (i + 1 < line.length() && !('0' <= line.charAt(i + 1) && line.charAt(i + 1) <= '9')
				|| i + 1 == line.length()))
			{
				return true;
			}
		}
		return false;
	}
}
