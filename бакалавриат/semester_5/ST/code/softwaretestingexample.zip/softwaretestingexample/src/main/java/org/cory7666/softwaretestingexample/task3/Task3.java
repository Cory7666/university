package org.cory7666.softwaretestingexample.task3;

public class Task3
{
	public Task3 ()
	{
		System.out.println("=== Тесты для Задания 3 ===");
	}

	public void execute ()
	{
		this
			.test("34")
			.test("Было подобрано число 33.")
			.test("101 далматинец")
			.test("2022 год")
			.test("13 литров 00509 миллилитров")
			.test("11 точка 0000900");
	}

	private Task3 test (String toTest)
	{
		System.out.printf("Тест для: <%s>. Итог: %b.\n", toTest, new MyLine(toTest).containsThreeDigitNumber());
		return this;
	}
}
