package org.cory7666.softwaretestingexample.task1;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class MatrixTest
{
	@Test
	public void test_nullData_ExceptionThrowed ()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Matrix(null);
		});
	}

	@Test
	public void test_1by1Matrix_0column ()
	{
		Assertions.assertEquals(0, new Matrix(new int[][] { { 1 } }).columnPositionWithLongestSeries());
	}

	@Test
	public void test_longestSeriesInLeftTopCorner_0column ()
	{
		Assertions
			.assertEquals(
				0,
				new Matrix(new int[][] { { 1, 1, 2, 1 }, { 2, 4, 78, 100 }, { 3, 5, 11, 5 } })
					.columnPositionWithLongestSeries());
	}

	@Test
	public void test_longestSeriesInMiddle_1column ()
	{
		Assertions
			.assertEquals(
				1,
				new Matrix(new int[][] { { 1, -1, 10, 20 }, { 1, 2, 2, 20 }, { 1, -1, 10, 20 }, { 1, -1, 10, 20 } })
					.columnPositionWithLongestSeries());
	}

	@Test
	public void test_longestSeriesInRightBottomCorner_4column ()
	{
		Assertions
			.assertEquals(
				4,
				new Matrix(
					new int[][] { { 1, 2, 2, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 2, 3, 4 }, { 1, 10, 10, 10 } })
					.columnPositionWithLongestSeries());
	}
}
